//
//  SwiftZSTD_iOS.h
//  SwiftZSTD_iOS
//
//  Created by Anatoli on 12/20/16.
//
//

#import <UIKit/UIKit.h>

//! Project version number for SwiftZSTD_iOS.
FOUNDATION_EXPORT double SwiftZSTDVersionNumber;

//! Project version string for SwiftZSTD_iOS.
FOUNDATION_EXPORT const unsigned char SwiftZSTDVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftZSTD_iOS/PublicHeader.h>

#import "zstd.h"
#import "zdict.h"

#import "StreamHelpers.h"

