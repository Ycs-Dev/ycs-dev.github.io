//
//  ViewController.swift
//  iOSTestApp
//
//  Created by Anatoli on 1/20/20.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
}

