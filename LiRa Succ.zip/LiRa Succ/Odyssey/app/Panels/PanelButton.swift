//
//  PanelButton.swift
//  Odyssey
//
//  Created by CoolStar on 7/5/20.
//  Copyright © 2020 coolstar. All rights reserved.
//

import UIKit

class PanelButton: TableButton {
    @IBOutlet var childPanel: (UIView & PanelView)!
}
